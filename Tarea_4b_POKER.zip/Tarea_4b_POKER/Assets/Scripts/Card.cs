﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Card
{
    // Atributos clase Card.
    public string Carta;
    public string Palo;
    public int Puntos;

    public Card(string Carta, string Palo, int Puntos)   // Constructor atributos de la clase.
    {
        this.Carta = Carta;
        this.Palo = Palo;
        this.Puntos = Puntos;
    }

    public void PrintInfo()         // Metodo para presentar los atributos de cada carta.
    {
        Debug.Log("\tCarta:\t" + Carta + " " + Palo);
        Debug.Log("\tPuntos:\t" + Puntos + "  Puntos");
    }
}
