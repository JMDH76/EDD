﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    string[] palos = new string[] { "Picas", "Corazones", "Tréboles", "Diamantes" };                            // Array de palos
    string[] cartas = new string[] { "As", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", };      // Array nombres de cada carta
    int[] puntos = new int[] { 10, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10 };                                    // Valor d ecada carta

    void Start()
    {
        List<Card> mazo = new List<Card>();             // Lista para guardar la baraja de 52 cartas
        Player player = new Player("Jugador1", 0);      // Creamos el objeto jugador

        //Iniciador
        InitDeck();                             // Invocamos InitDeck para generar la baraja
        for (int i = 0; i < 5; i++)             // Bucle para sacar la siguiente carta
        {
            Debug.Log("\t" + player.nombre + ":");      // Presentación / Maquetado
            nextCard();                                 // Invocamos metodo para repartir carta 
            Debug.Log("\n");                            // Presentación / Maquetado
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        // Generamos la baraja completa
        void InitDeck()  // Metodo de inicialización de la baraja
        {
            for (int i = 0; i < palos.Length; i++)   // Bucle para asignar palo
            {
                for (int h = 0; h < 13; h++)                                    // Bucle para asignar número de carta
                {
                    Card cards = new Card(cartas[h], palos[i], puntos[h]);      // Generamos objetos carta 
                    mazo.Add(cards);                                            // los añadimos a la lista de la baraja (mazo)
                }
            }
        }

        // saca la siguiente carta y presenta la puntuaciónacumulada
        void nextCard()
        {
            int carta = Random.Range(0, mazo.Count);                                            // Generamos un numero aleatorio (ínidce) para seleccionar la carta dentro de la lista
            Card card = new Card(mazo[carta].Carta, mazo[carta].Palo, mazo[carta].Puntos);      // Creamos el objeto carta aleatorio usando el indice obtenido arriba
            mazo.RemoveAt(carta);                                                               // Borramos el objeto carta del mazo para que no se repita
            card.PrintInfo();                                                                   // Invocamos función y mostramos por pantalla la información de la carta que vamos a repartir
            player.dealCard(card);                                                              // enviamos la carta a dealCard en Player class y así meterla en su mano
            Debug.Log("\tPuntuación acumulada:\t" + player.getPoints() + " puntos");            // invocamos getPoints para ver los puntos acumulados
        }
    }

    void Update()
    {

    }
}
