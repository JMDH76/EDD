﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player
{
    List<Card> manoJugador = new List<Card>();   //Lista para incluir las cartas dela mano. Las pasas dealCard

    // Atributos clase Player
    public string nombre;
    int puntuacion;

    // Constructor de objetos
    public Player(string nombre, int puntuacion)
    {
        this.nombre = nombre;
        this.puntuacion = puntuacion;
    }

    public void dealCard(Card card)  //recibe una carta de nextCard y la mete en la lista
    {
        manoJugador.Add(card);       //añadimos carta a la lista "manoJugador"
        setPoints(card.Puntos);     // pasamos a setPoints los puntos de la carta para sumarlos a la puntuacioon final 
    }

    void setPoints(int v)           // recibe valor desde "dealCard(Card card)"
    {
        puntuacion += v;        // suma puntos al de la carta a la puntuación total
    }

    public int getPoints()      // metodo para devolver la puntuación total    
    {
        return puntuacion;      // devuelve el valor de la puntuación total
    }
}
